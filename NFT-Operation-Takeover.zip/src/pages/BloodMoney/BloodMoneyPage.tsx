import Loading from 'components/loading/Loading';
import Menu from 'components/menu/Menu';
import Topbar from 'components/topbar/Topbar';
import { useEffect, useState } from 'react';
import './style.scss'
import Footer from 'components/sections/footer/Footer';

export default function BloodMoneyPage() {
    const [isLoading, setIsLoading] = useState(true);
    const [isLoading1, setIsLoading1] = useState(true);

    window.onload = () => {
        setIsLoading(false)
    };

    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 2 && !isLoading1){
            setTimeout(() => {
                setIsLoading(false)
            }, 500);
        }
    }, [setIsLoading, imgCount, isLoading1]);


    return (
        <>
            <Topbar/>
            <Menu/>
            <Loading isLoading={isLoading} />
            <div className="sections" id = 'home'>
                <div className="bloodMoney">
                    <div className="content">
                        <h1>wHAT IS $bLOODMONEY?</h1>
                        <div className="item border">
                            <img src="/assets/c966ca_e84c732194d24986ba35de321db426ef_mv2.gif" alt="" onLoad={onLoad}/>
                            <div className="text">
                                <p>Since Cueballs rise in power, $BloodMoney has become the heart of the eco system within Elysian City.</p>

                                <p>Agents can passively earn $BloodMoney daily with boosts being applied to those who climb the food chain and show their loyalty to Cueball.</p>

                                <p>Boosts will also be applied to higher tier traits.</p>

                                <p>$BloodMoney will give our community more power than ever before, giving us the resources to grow The Agency into an unstoppable army.</p>
                            </div>
                        </div>
                        <div className="wrapper border">
                            <div className="item right">
                                <div className="text">
                                    <h2>Passively earn</h2>
                                    <p>Being a genetic clone of the biggest mob boss in the city is not all fun and games, but it sure does pay well. Unlisted agents passively earn 10 $BloodMoney per day just for holding them</p>
                                </div>
                                <img src="/assets/c966ca_53e55d4099484a38b409ec73de72ffb3_mv2.gif" alt="" onLoad={onLoad}/>
                            </div>
                            <div className="item left">
                            <div className="text">
                                    <h2>Customise your backstory</h2>
                                    <p>Let your agents origins be know.... for a small fee. Customise your agents name and lore directly onto the blockchain with your $BloodMoney. Every agent has a sinister story to tell.</p>
                                </div>
                                <img src="" alt="" />
                            </div>
                            <div className="item right">
                            <div className="text">
                                    <h2>The black Market</h2>
                                    <p>Come aboard the deadliest ship in the sea and purchase a wide variety of digital and physical items that every agent will need. No ID required.</p>
                                </div>
                                <img src="" alt="" />
                            </div>
                            <div className="item left">
                            <div className="text">
                                    <h2>level your agent</h2>
                                    <p>Tired of being the new recruit? Invest $BloodMoney into your agent to increase his level. Once maxed out, you can prestige to the next badge and get some amazing reward boosts and unlockables.</p>
                                </div>
                                <img src="" alt="" />
                            </div>
                            <div className="item right">
                            <div className="text">
                                    <h2>Live like a king</h2>
                                    <p>Leave the cloning chamber behind and get a roof over your head. Spend your $BloodMoney to buy and upgrade your very own apartment within Elysian city. </p>
                                </div>
                                <img src="" alt="" />
                            </div>
                            <div className="item left">
                            <div className="text">
                                    <h2>Chest your luck</h2>
                                    <p>If there's one thing Red eye loves most, it's money. Test your luck and open a variety of chests holding different rewards, one of them only to be opened using $BloodMoney.</p>
                                </div>
                                <img src="" alt="" />
                            </div>
                            <h1>more coming soon.....</h1>
                            
                        </div>
                    </div>
                </div>
                <Footer setIsLoading={setIsLoading1}/>
            </div>
        </>
    )
}
