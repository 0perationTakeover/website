import Loading from 'components/loading/Loading';
import { useEffect, useState } from 'react';
import StakingCard from 'components/stakingCard';
import toast from 'react-hot-toast';
import { useWeb3React } from '@web3-react/core';
import { currentNetwork, truncateWalletString } from 'utils';
import { scGetStakingEngineInfo, scHarvest, scStakeNFTs, scUnStakeNFTs } from 'utils/contracts';
import { NFTStakingEngineDetail } from 'utils/typs';

import './style.scss';
import SideBar from 'components/sideBar/SideBar';
import AccountModal from 'components/modals/accountModal/AccountModal';
import ConnectModal from 'components/modals/connectModal/ConnectModal';
export default function StakingPage() {
    const [isLoading, setIsLoading] = useState(true);
    const [isLoading1, setIsLoading1] = useState(true);
    window.onload = () => {
        setIsLoading(false)
    };
    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 1 && !isLoading1) {
            setTimeout(() => {
                setIsLoading(false)
            }, 100);
        }
    }, [setIsLoading, imgCount, isLoading1]);
    const { connector, library, chainId, account, active } = useWeb3React();
    const [showConnectModal, setShowConnectModal] = useState(false);
    const [showAccountModal, setShowAccountModal] = useState(false);

    // ======  selected ID list ======== by XU 
    const [selectedCurrentNFTList, setSelectedCurrentNFTList] = useState([]);
    // ========= selected ID list =========  by XU
    const [selectedStakedNFTList, setSelectedStakedNFTList] = useState([]);

    const [isLoadedCurrentNFTList, setIsLoadedCurrentNFTList] = useState(false);
    const [isLoadedStakedNFTList, setIsLoadedStakedNFTList] = useState(false);

    const [loginStatus, setLoginStatus] = useState(true);
    const [stakingEngineDetail, setStakingEngineDetail] = useState<NFTStakingEngineDetail>(null);
    useEffect(() => {
        // const account = '0xBf8fF255aD1f369929715a3290d1ef71d79f8954'
        const isLoggedin = account && active && chainId === parseInt(currentNetwork);
        setLoginStatus(isLoggedin);

        if (isLoggedin) {
            scGetStakingEngineInfo(account).then(
                (engineDetail: NFTStakingEngineDetail) => {
                    setStakingEngineDetail(engineDetail);
                    setIsLoadedCurrentNFTList(true);
                    setIsLoadedStakedNFTList(true);
                }
            );
        }
    }, [connector, library, account, active, chainId]);

    const stakeSelectedNFT = async () => {
        if (!loginStatus) {
            toast.error("Please connect wallet correctly!");
            return;
        }

        if (selectedCurrentNFTList.length <= 0) {
            toast.error("Selcted NFT count should be higher than 0");
            return;
        }

        const load_toast_id = toast.loading("Please wait for Staking...");
        try {
            const bSuccess = await scStakeNFTs(chainId, library.getSigner(), account, selectedCurrentNFTList);
            if (bSuccess) {
                toast.success("Staking Success!");
                setTimeout(() => {
                    scGetStakingEngineInfo(account).then(
                        (engineDetail: NFTStakingEngineDetail) => {
                            setStakingEngineDetail(engineDetail);
                            setIsLoadedCurrentNFTList(true);
                            setIsLoadedStakedNFTList(true);
                        }
                    );
                }, 2000);
            } else {
                toast.error("Staking Failed!");
            }
        } catch (error) {
            toast.error("Staking Failed!");
        }
        toast.dismiss(load_toast_id);
    }

    const unstakeSelectedNFT = async () => {
        if (!loginStatus) {
            toast.error("Please connect wallet correctly!");
            return;
        }

        if (selectedStakedNFTList.length <= 0) {
            toast.error("Selcted NFT count should be higher than 0");
            return;
        }

        const load_toast_id = toast.loading("Please wait for Unstaking...");
        try {
            const bSuccess = await scUnStakeNFTs(chainId, library.getSigner(), selectedStakedNFTList);
            if (bSuccess) {
                toast.success("Unstaking Success!");
                setTimeout(() => {
                    scGetStakingEngineInfo(account).then(
                        (engineDetail: NFTStakingEngineDetail) => {
                            setStakingEngineDetail(engineDetail);
                            setIsLoadedCurrentNFTList(true);
                            setIsLoadedStakedNFTList(true);
                        }
                    );
                }, 2000);
            } else {
                toast.error("Unstaking Failed!");
            }
        } catch (error) {
            toast.error("Unstaking Failed!");
        }
        toast.dismiss(load_toast_id);
    }

    const handleClaim = async () => {
        if (!loginStatus) {
            toast.error("Please connect wallet correctly!");
            return;
        }
        const load_toast_id = toast.loading("Please wait for Claim Reward...");
        try {

            const bSuccess = await scHarvest(chainId, library.getSigner());
            if (bSuccess) {
                toast.success("Claiming Success!");
                setTimeout(() => {
                    scGetStakingEngineInfo(account).then(
                        (engineDetail: NFTStakingEngineDetail) => {
                            setStakingEngineDetail(engineDetail);
                            setIsLoadedCurrentNFTList(true);
                            setIsLoadedStakedNFTList(true);
                        }
                    );
                }, 2000);
            } else {
                toast.error("Claiming Failed!");
            }
        } catch (error) {
            toast.error("Claiming Failed!");
        }
        toast.dismiss(load_toast_id);
    }

    return (
        <>
            <SideBar setIsLoading={setIsLoading1} />
            <Loading isLoading={isLoading} />
            <div className="sections" >
                <div className="seasonSection">
                    <div className="topBtns">
                        <div className={"connectBtn button"} onClick={() => { !loginStatus ? setShowConnectModal(true) : setShowAccountModal(true) }}>
                            {loginStatus ? truncateWalletString(account) : "CONNECT WALLET"}
                        </div>
                        <div className="socialLinks">
                            <a href="/" target="_blank"rel="noreferrer">
                                <img src="/assets/opensea.png" alt="" onLoad={onLoad} />
                            </a> 
                            <a href="https://twitter.com/Operation_TKO" target="_blank"rel="noreferrer">
                            <img src="/assets/twitter.png" alt="" />
                            </a> 
                            <a href="https://discord.gg/v885RBtttf" target="_blank"rel="noreferrer">
                            <img src="/assets/discord.png" alt=""  />
                            </a> 
                        </div>
                    </div>

                    <div className="seasonContent" >
                        <h1 data-aos="fade-up">Staking</h1>
                        <div className="calm">
                            <div className="row">
                                <div className="col">
                                    <h2>Claimable $BLOODMONEY : <span>{(stakingEngineDetail?.pendingRewards || 0).toFixed(3)}</span></h2>
                                </div>
                                <button className="claimBtn button" disabled={!loginStatus} onClick={handleClaim} >CLAIM
                                </button>
                            </div>
                            <div className="row">
                                <ul>
                                    <li>
                                        <i className="fas fa-chart-line icon"></i>
                                        <span>
                                            <p>Base rate</p>
                                            <h5>{(stakingEngineDetail?.stakedNFTList.length * 10 || 0)}</h5>
                                        </span>
                                    </li>
                                    <li>
                                        <i className="fas fa-gem icon"></i>
                                        <span>
                                            <p>Rarity bonus</p>
                                            <h5>{(stakingEngineDetail?.rewardsPerDay - stakingEngineDetail?.stakedNFTList.length * 10 || 0)}</h5>
                                        </span>
                                    </li>
                                    <li>
                                        <i className="fas fa-user-tie icon"></i>
                                        <span>
                                            <p>VIP</p>
                                            <h5>0.00</h5>
                                        </span>
                                    </li>
                                    <li>
                                        <i className="fas fa-building icon"></i>
                                        <span>
                                            <p>Apartment</p>
                                            <h5>0.00</h5>
                                        </span>
                                    </li>
                                </ul>




                            </div>

                        </div>
                        <h5>Select NFTs to stake or unstake.</h5>
                        {!loginStatus ?
                            <div className="wrapper" >
                                <div className="noneWallet" data-aos="fade-up">
                                    <h2>Please connect wallet</h2>
                                </div>
                            </div> :
                            <>
                                <div className="wrapper" >
                                    <div className="left">
                                        <StakingCard
                                            nfts={stakingEngineDetail?.currentNFTList || []}
                                            dataLoaded={isLoadedCurrentNFTList}

                                            selectdNftIds={selectedCurrentNFTList}
                                            setSelectedNftIds={setSelectedCurrentNFTList}
                                            OnStake={stakeSelectedNFT}
                                        />
                                    </div>
                                    <div className="center">
                                        <div className="line"></div>
                                        <div className="arrow">
                                            <i className="fas fa-sync-alt"></i>
                                        </div>
                                        <h4>Stake</h4>
                                        <div className="line"></div>
                                    </div>
                                    <div className="right">
                                        <StakingCard
                                            nfts_staked={stakingEngineDetail?.stakedNFTList || []}

                                            dataLoaded={isLoadedStakedNFTList}
                                            isStaked

                                            selectdNftIds_Staked={selectedStakedNFTList}
                                            setSelectedNftIds_Staked={setSelectedStakedNFTList}
                                            OnUnStake={unstakeSelectedNFT}

                                            lastUpdated={Number(stakingEngineDetail?.lastUpdatedTime || 0)}
                                        />

                                    </div>

                                </div>
                            </>
                        }
                    </div>
                </div>
            </div>
            <AccountModal showAccountModal={showAccountModal} setShowAccountModal={setShowAccountModal} />
            <ConnectModal showConnectModal={showConnectModal} setShowConnectModal={setShowConnectModal} />
        </>
    )
}
