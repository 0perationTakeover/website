import Loading from 'components/loading/Loading';
import { useState } from 'react';


import './style.scss';
import Topbar from 'components/topbar/Topbar';
import Menu from 'components/menu/Menu';
import Footer from 'components/sections/footer/Footer';
export default function BlackMarketPage() {
    const [isLoading, setIsLoading] = useState(true);
    window.onload = () => {
        setIsLoading(false)
    };


    return (
        <>
            <Topbar/>
            <Menu/>
            <Loading isLoading={isLoading} />
            <div className="sections" >
                <div className="blackMarket">
                    <div className="content" >
                        <h1>coming soon</h1>
                    </div>
                    <Footer setIsLoading={setIsLoading}/>
                </div>
                
            </div>
        </>
    )
}
