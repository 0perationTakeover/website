import Loading from 'components/loading/Loading';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { useWeb3React } from '@web3-react/core';
import { currentNetwork, truncateWalletString } from 'utils';

import './style.scss';
import SideBar from 'components/sideBar/SideBar';
import AccountModal from 'components/modals/accountModal/AccountModal';
import ConnectModal from 'components/modals/connectModal/ConnectModal';
import Masonry from 'react-masonry-css';
import CollectionCard from 'components/collectionCard';
import CollectionModal from 'components/modals/collectionModal/CollectionModal';
import { NFTStakingEngineDetail } from 'utils/typs';
import { scGetStakingEngineInfo } from 'utils/contracts';
import { BigNumber } from 'ethers';
import Rarity_Tree from 'utils/merkleTree/rarityTree.json'
const breakpointColumnsObj = {
    default: 5,
    1840: 5,
    1440: 4,
    1280: 3,
    768: 2,
    450: 1,
};

export default function MyCollectionPage() {
    const [isLoading, setIsLoading] = useState(true);
    const [isLoading1, setIsLoading1] = useState(true);
    window.onload = () => {
        setIsLoading(false)
        setIsLoading1(false)
    };
    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 1 && !isLoading1){
            setTimeout(() => {
                setIsLoading(false)
            }, 100);
        }
    }, [setIsLoading, imgCount, isLoading1]);
    const { connector, library, chainId, account, active } = useWeb3React();
    const [showConnectModal, setShowConnectModal] = useState(false);
    const [showAccountModal, setShowAccountModal] = useState(false);
    const [showItemModal, setShowItemModal] = useState(false);

    const [loginStatus, setLoginStatus] = useState(true);
    const [stakingEngineDetail, setStakingEngineDetail] = useState<NFTStakingEngineDetail>(null);
    const [myCollections, setMyCollections] = useState<BigNumber[]>([]);
    const [stakedList, setStakedList] = useState<BigNumber[]>([]);
    
    useEffect(() => {
        // const account = '0xBf8fF255aD1f369929715a3290d1ef71d79f8954'
        const isLoggedin = account && active && chainId === parseInt(currentNetwork);
        setLoginStatus(isLoggedin);
        if (isLoggedin) {
            scGetStakingEngineInfo(account).then(
                (engineDetail: NFTStakingEngineDetail) => {
                    setStakingEngineDetail(engineDetail);
                    setMyCollections([...engineDetail?.currentNFTList || [], ...engineDetail?.stakedNFTList|| []])
                    setStakedList(engineDetail?.stakedNFTList|| [])
                }
            );
        }
    }, [connector, library, account, active, chainId]);
    const tab_list = ['Agents','VIP','APARTMENT','ALL']
    const [tabID, setTabID] = useState(0);

    const getRarity = (id : string)=>{
        const rarity_list = ['Associate', 'Soldier', 'Caporegime', 'Consigliere', 'Underboss', 'Boss']
        return rarity_list[Rarity_Tree['claims'][id].rarity]
    }
    
    const [select, setSelect] = useState('All');
    const handleOnChange = (e)=>{
        console.log(e.target.value)
        setSelect(e.target.value)
    }
    // useEffect(() => {
    //     if(loginStatus && stakingEngineDetail){
    //         if(select === 'staked'){
    //             setMyCollections(stakingEngineDetail?.stakedNFTList || [])
    //         }
    //         else if(select === 'not staked'){
    //             setMyCollections(stakingEngineDetail?.currentNFTList || [])
    //         }
    //         else{
    //             setMyCollections([...stakingEngineDetail?.currentNFTList, ...stakingEngineDetail?.stakedNFTList] || [])
    //         }
    //     }
    // }, [stakingEngineDetail, loginStatus, select]);

    useEffect(() => {
        if(loginStatus && stakingEngineDetail){
            if(tabID === 0 || tabID === 3){
                if(select === 'staked'){
                    setMyCollections(stakingEngineDetail?.stakedNFTList || [])
                }
                else if(select === 'not staked'){
                    setMyCollections(stakingEngineDetail?.currentNFTList || [])
                }
                else if(select === 'rarity'){
                    const all_NFT = [...stakingEngineDetail?.currentNFTList, ...stakingEngineDetail?.stakedNFTList]

                    const filter1 = all_NFT.filter(id=>Rarity_Tree['claims'][id]['rarity'] === 5)
                    const filter2 = all_NFT.filter(id=>Rarity_Tree['claims'][id]['rarity'] === 4)
                    const filter3 = all_NFT.filter(id=>Rarity_Tree['claims'][id]['rarity'] === 3)
                    const filter4 = all_NFT.filter(id=>Rarity_Tree['claims'][id]['rarity'] === 2)
                    const filter5 = all_NFT.filter(id=>Rarity_Tree['claims'][id]['rarity'] === 1)
                    const filter6 = all_NFT.filter(id=>Rarity_Tree['claims'][id]['rarity'] === 0)

                    setMyCollections([...filter1, ...filter2, ...filter3, ...filter4, ...filter5, ...filter6])
                }
                else{
                    setMyCollections([...stakingEngineDetail?.currentNFTList, ...stakingEngineDetail?.stakedNFTList] || [])
                }
            }
            else{
                setMyCollections([])
            }

            
        }
    }, [stakingEngineDetail, tabID, loginStatus, select]);

    const [collection, setCollection] = useState<BigNumber>(null);
    const handleClick = (id : BigNumber)=>{
        setCollection(id)
        setShowItemModal(true)
    }
    const onBuy = ()=>{
        if(!loginStatus){
            toast.error('Please connect wallet!')
            return
        }
    }

    return (
        <>
            <SideBar setIsLoading={setIsLoading1}/>
            <Loading isLoading={isLoading} />
            <div className="sections" >
                <div className="mycollection">
                    <div className="topBtns">
                        <div className={"connectBtn button"} onClick={() => { !loginStatus ? setShowConnectModal(true) : setShowAccountModal(true) }}>
                            {loginStatus ? truncateWalletString(account) : "CONNECT WALLET"}
                        </div>
                        <div className="socialLinks">
                            <a href="/" target="_blank"rel="noreferrer">
                                <img src="/assets/opensea.png" alt="" onLoad={onLoad} />
                            </a> 
                            <a href="https://twitter.com/Operation_TKO" target="_blank"rel="noreferrer">
                            <img src="/assets/twitter.png" alt="" />
                            </a> 
                            <a href="https://discord.gg/v885RBtttf" target="_blank"rel="noreferrer">
                            <img src="/assets/discord.png" alt=""  />
                            </a> 
                        </div>
                    </div>

                    <div className="content" >
                        <h1 data-aos="fade-up">My Collection</h1>
                        <div className="state">
                            <ul>
                                <li>
                                    <p>TOTAL OWNED : </p>
                                    <h4>{stakingEngineDetail?.currentNFTList.length + stakingEngineDetail?.stakedNFTList.length || 0}</h4>
                                </li>
                                <li>
                                    <p>$BLOODMONEY balance : </p>
                                    <h4>{(stakingEngineDetail?.rewardsTokenBalance || 0).toFixed(2)}</h4>
                                </li>
                                <li>
                                    <p>$BLOODMONEY income</p>
                                    <h4>{(stakingEngineDetail?.rewardsPerDay || 0).toFixed(2)}</h4>
                                </li>
                            </ul>
                        </div>

                        <div className="wrapper" >
                            <div className="tabList">
                                {tab_list.map((d, k)=>(
                                    <div className={`tab ${tabID === k ? 'activeTab' : ''}`} key = {k} onClick = {()=>setTabID(k)}>
                                        {d}
                                    </div>
                                ))}
                                
                            </div>

                            <select
                                className="filter-select"
                                name="filter"
                                id="filter"
                                value={select}
                                onChange={(e) => handleOnChange(e)}
                                >
                                <option value="all">All</option>
                                <option value="staked">staked</option>
                                <option value="not staked">not staked</option>
                                <option value="rarity">Rarity</option>
                                </select>

                            {myCollections.length === 0 ? 
                                <div className="noneWallet">
                                    <h2>NO NFTs FOUND</h2>
                                </div>:
                                (loginStatus ? 
                                    <div className="nftList">
                                    <Masonry
                                        breakpointCols={breakpointColumnsObj}
                                        className="masonry"
                                        columnClassName="gridColumn"
                                    >   
                                        {myCollections.map((id, key) => (
                                            <CollectionCard key={key} id={id.toString()} onClick = {()=>handleClick(id)} rarity = {getRarity(id.toString())}/> )
                                        )}
                                        
                                    </Masonry>
                                    </div>:
                                    <div className="noneWallet">
                                        <h2>Please connect wallet</h2>
                                    </div>
                                )
                            }
                            
                        </div>
                    </div>
                </div>
            </div>
            <AccountModal  showAccountModal={showAccountModal} setShowAccountModal={setShowAccountModal} />
            <ConnectModal showConnectModal={showConnectModal} setShowConnectModal={setShowConnectModal} />
            <CollectionModal showModal={showItemModal} setShowModal={setShowItemModal} nft = {collection} isStaked = {stakedList?.indexOf(collection) > -1} onBuy = {onBuy}/>
        </>
    )
}
