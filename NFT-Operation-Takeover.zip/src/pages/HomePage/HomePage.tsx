import Loading from 'components/loading/Loading';
import Menu from 'components/menu/Menu';
import Topbar from 'components/topbar/Topbar';
import { useEffect, useState } from 'react';
import Home from 'components/sections/home/Home';
import Roadmap from 'components/sections/roadmap/Roadmap';
import Rarity from 'components/sections/rarity/Rarity';
import Team from 'components/sections/team/Team';
import Community from 'components/sections/community/Community';
import Footer from 'components/sections/footer/Footer';

export default function HomePage() {
    const [isLoading, setIsLoading] = useState(true);
    const [isLoading1, setIsLoading1] = useState(true);
    const [isLoading2, setIsLoading2] = useState(true);
    const [isLoading3, setIsLoading3] = useState(true);
    const [isLoading4, setIsLoading4] = useState(true);
    const [isLoading5, setIsLoading5] = useState(true);
    const [isLoading6, setIsLoading6] = useState(true);

    window.onload = () => {
        setIsLoading(false)
        setIsLoading1(false)
        setIsLoading2(false)
        setIsLoading3(false)
        setIsLoading4(false)
        setIsLoading5(false)
        setIsLoading6(false)
    };
    
    useEffect(() => {
        console.log(isLoading1, isLoading2, isLoading3, isLoading4, isLoading5, isLoading6)
        if (!isLoading1 && !isLoading2 && !isLoading3 && !isLoading4 && !isLoading5 && !isLoading6){
            setTimeout(() => {
                setIsLoading(false)
            }, 500);
        }
    }, [isLoading1, isLoading2, isLoading3, isLoading4, isLoading5, isLoading6, setIsLoading]);

    return (
        <>
            <Topbar/>
            <Menu/>
            <Loading isLoading={isLoading} />
            <div className="sections">
                <Home setIsLoading={setIsLoading1}/>
                <Roadmap setIsLoading={setIsLoading2}/>
                <Rarity setIsLoading={setIsLoading3}/>
                <Team setIsLoading={setIsLoading4}/>
                <Community setIsLoading={setIsLoading5}/>
                <Footer setIsLoading={setIsLoading6}/>
            </div>
        </>
    )
}
