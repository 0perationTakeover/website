import './title.scss'

type PropsType = {
    label? : any;
    
};

export default function Title({label}:PropsType) {
  return (
    <div className='title'>
      <div className="mesh_top"></div>
      <div className="mesh_bottom"></div>
      <div className="text">
        {label}
      </div>
    </div>
  )
}
