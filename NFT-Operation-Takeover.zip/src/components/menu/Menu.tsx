import "./menu.scss"
import {HashLink} from 'react-router-hash-link'
import { useEffect, useState } from "react";
import { useHistory } from "react-router";

export default function Menu() {
    const [menuOpen, setMenuOpen] = useState(false);

    const [tabID, setTabID] = useState('mycollection');
    const location = useHistory();
    useEffect(() => {
        const path = location.location.pathname.replace('/','')
        setTabID(path)
    }, [location]);
    return (
       <>
        <div className={"menu " + (menuOpen && "active")}>
            <ul>
                <li onClick = {()=> setMenuOpen(false)} className = {"menuItem1 " + (menuOpen && "active")}>
                <HashLink to="/#about" smooth style={{color : tabID === 'bloodmoney' ? '#f00' : '#58CCFA'}}>ABOUT</HashLink>
                </li>
                <li onClick = {()=> setMenuOpen(false)} className = {"menuItem2 " + (menuOpen && "active")}>
                <HashLink to="/#roadmap" smooth  style={{color : tabID === 'bloodmoney' ? '#f00' : '#58CCFA'}}>Roadmap</HashLink>
                </li>


                <li onClick = {()=> setMenuOpen(false)} className = {"menuItem3 " + (menuOpen && "active")}>
                    <HashLink to="/bloodmoney" style={{color : tabID === 'bloodmoney' ? '#f00' : '#58CCFA'}}>$BLOODMONEY</HashLink>
                </li>
                <li onClick = {()=> setMenuOpen(false)} className = {"menuItem4 " + (menuOpen && "active")}>
                <a href="/mycollection"  target="_blank"rel="noreferrer" style={{color : tabID === 'bloodmoney' ? '#f00' : '#58CCFA'}}>DASHBOARD</a>
                </li>

                <li onClick = {()=> setMenuOpen(false)} className = {"menuItem5 " + (menuOpen && "active")}>
                <HashLink to="/black-market" smooth style={{color : tabID === 'bloodmoney' ? '#f00' : '#58CCFA'}}>BLACK MARKET</HashLink>
                </li>
                <li onClick = {()=> setMenuOpen(false)} className = {"menuItem8 " + (menuOpen && "active")}>
                    <div className="socialLinks">
                        <a href="/" target="_blank"rel="noreferrer">
                            <img src="/assets/opensea.webp" alt="" />
                        </a> 
                        <a href="https://twitter.com/Operation_TKO" target="_blank"rel="noreferrer">
                            <i className="fab fa-twitter"></i>
                        </a> 
                        <a href="https://discord.gg/v885RBtttf" target="_blank"rel="noreferrer">
                            <i className="fab fa-discord"></i>
                        </a> 
                    
                    </div>
                </li>
            </ul>
        </div>
        <div className={(menuOpen ? "hamburger1 active" : "hamburger1")} onClick={() => setMenuOpen(!menuOpen)}>
            <span className="line1" style={{backgroundColor : tabID === 'bloodmoney' ? '#f00' : '#58CCFA'}}></span>
            <span className="line2" style={{backgroundColor : tabID === 'bloodmoney' ? '#f00' : '#58CCFA'}}></span>
            <span className="line3" style={{backgroundColor : tabID === 'bloodmoney' ? '#f00' : '#58CCFA'}}></span>
        </div>
        </>
    )
}

