import { useWeb3React } from '@web3-react/core';
import AccountModal from '../modals/accountModal/AccountModal';
import { useEffect, useState } from 'react';
import { HashLink } from 'react-router-hash-link'
import { truncateWalletString } from 'utils';
import ConnectModal from '../modals/connectModal/ConnectModal';
import './topbar.scss'
import { useHistory } from 'react-router-dom';


export default function Topbar() {
    const [showConnectModal, setShowConnectModal] = useState(false);
    const [showAccountModal, setShowAccountModal] = useState(false);

    const [loginStatus, setLoginStatus] = useState(false);
    const { connector, library, chainId, account, active } = useWeb3React();
    useEffect(() => {
        const isLoggedin = account && active && chainId === parseInt(process.env.REACT_APP_NETWORK_ID, 10);
        setLoginStatus(isLoggedin);
    }, [connector, library, account, active, chainId]);

    const [tabID, setTabID] = useState('mycollection');
    const location = useHistory();
    useEffect(() => {
        const path = location.location.pathname.replace('/','')
        setTabID(path)
    }, [location]);

    const [isScrolled, setIsScrolled] = useState(false);
    window.onscroll = () => {
		const scrolltop = window.pageYOffset;

		if (scrolltop >80) {
            setIsScrolled(true)
		}
        else{
            setIsScrolled(false)
        }

		return () => (window.onscroll = null);
	}
    return (
        <div className={`topbar ${isScrolled ? 'scrolled':''}`}>
            <div className="logo">
                <HashLink to="/" >
                    {tabID === 'bloodmoney' ? 
                    <img src="assets/Text for Banner - Upscaled size - 06.webp" alt="" className=''/>:
                    <img src="assets/logo.webp" alt="" className=''/>}
                    {/* <img src="assets/logo.webp" alt="" className='mob'/> */}
                </HashLink>
            </div>
           
            <div className="btns">
                <div className="navList">
                    <ul>
                        <li><HashLink to="/#about" smooth>ABOUT</HashLink></li>
                        <li><HashLink to="/#roadmap" smooth>ROADMAP</HashLink></li>
                        <li><HashLink to="/bloodmoney" smooth>$BLOODMONEY</HashLink></li>
                        <li><a href="/mycollection" target="_blank"rel="noreferrer">DASHBOARD</a></li>
                        {/* <li><HashLink to="/mycollection" smooth>DASHBOARD</HashLink></li> */}
                        <li><HashLink to="/black-market" smooth>BLACK MARKET</HashLink></li>
                        {/* <li><HashLink to="/mint" smooth>MINT</HashLink></li>
                        <li><HashLink to="/mycollection" smooth>MY COLLECTION</HashLink></li>
                        <li><HashLink to="/staking" smooth>STAKING</HashLink></li> */}
                    </ul>
                </div>
                <div className="col">
                    <div
                        className={"connectBtn button"}
                        onClick={() => { !loginStatus ? setShowConnectModal(true) : setShowAccountModal(true) }}
                        style = {{color : tabID === 'bloodmoney' ? '#f00' : '#58CCFA', borderColor : tabID === 'bloodmoney' ? '#f00' : '#58CCFA'}}
                    >
                        {loginStatus ? truncateWalletString(account) : "CONNECT WALLET"}
                        
                    </div>

                    <div className="socialLinks">
                        <a href="/" target="_blank"rel="noreferrer">
                            <img src="/assets/opensea.png" alt="" />
                        </a> 
                        <a href="https://twitter.com/Operation_TKO" target="_blank"rel="noreferrer">
                        <img src="/assets/twitter.png" alt="" />
                        </a> 
                        <a href="https://discord.gg/v885RBtttf" target="_blank"rel="noreferrer">
                        <img src="/assets/discord.png" alt="" />
                        </a> 
                    </div>

                </div>
                
                
               
            </div>

            <AccountModal  showAccountModal={showAccountModal} setShowAccountModal={setShowAccountModal} />
            <ConnectModal showConnectModal={showConnectModal} setShowConnectModal={setShowConnectModal} />
        </div>
    )
}
