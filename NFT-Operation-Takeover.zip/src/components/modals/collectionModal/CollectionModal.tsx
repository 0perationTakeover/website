import { useWeb3React } from '@web3-react/core'
import { BigNumber } from 'ethers'
import './collectionModal.scss'
import Rarity_Tree from 'utils/merkleTree/rarityTree.json'
interface Props {
    showModal: boolean,
    setShowModal?: any
    nft ? :BigNumber
    onBuy?:any
    isStaked?: boolean

}
const CollectionModal: React.FC<Props> = ({
    showModal,
    setShowModal,
    nft,
    isStaked,
    onBuy
}) => {

    const cloaseHandle = (e:any)=>{
        if(e.target.className.includes("collectionModal"))
        {
            setShowModal(false)
        }
    }
    const { account } = useWeb3React();
    const getRarity = (id : string)=>{
        const rarity_list = ['Associate', 'Soldier', 'Caporegime', 'Consigliere', 'Underboss', 'Boss']
        return rarity_list[Rarity_Tree['claims'][id]['rarity']]
      }
    return (
        <div className={showModal === true ? "collectionModal active" : "collectionModal"}onClick={(e) => {cloaseHandle(e)}}>
            <div className="modelContent">
                <div className="connectWalletHeader">
                    <button className="connectModalCloseButton" onClick={() => { setShowModal(false) }}><i className="fas fa-times"></i></button>
                </div>
                <div className="connectWalletWrapper">
                    <div className="left">
                        <img src={`/assets/nfts/empty.png`} alt="" />
                    </div>
                    <div className="right">
                        <span><h3>Agent name : </h3><h3>Operation Takeover</h3></span>
                        <span><h3>Agent number : </h3><h3>#{Number(nft?._hex)}</h3></span>
                        <span><h3>Agent Rarity : </h3><h3>{getRarity(Number(nft?._hex || 0).toString())}</h3></span>
                        {isStaked ? 
                        <span><h3>Status : </h3><h3>Staked</h3></span>:
                        <span><h3>Status : </h3><h3>Not Staked</h3></span>}
                        <span><h3>Agent Lore : </h3><h3>_</h3></span>
                        <span><h3>Agent Level : </h3><h3>1</h3></span>
                        <div className="progress_bar">
                            <div className="progress"style={{width : `${(1/10)* 100}%`}}></div>
                        </div>
                        
                        <a  className='buyBtn button'href={`https://opensea.io/${account}`} target="_blank" rel="noreferrer" >
                            VIEW ON OPENSEA
                        </a>
                        
                    </div>
                </div>
                
            </div>
        </div>
    )
}
export default CollectionModal;