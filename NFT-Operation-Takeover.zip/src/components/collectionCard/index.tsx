import { useEffect, useRef, useState } from 'react';
import './style.scss';

type PropsType = {
    id?: string
    rarity?:string
    onClick? :any
};

export default function CollectionCard({ id, onClick, rarity}: PropsType) {
    const nft_ref = useRef(null) 
    const [isLoaded, setIsLoaded] = useState(false);
    const handleLoad = (e:any)=>{
      
      if(e.isTrusted){
        setIsLoaded(true);
      }
      else{
        setIsLoaded(false);
      }
  
      
    }
    const [height, setHeight] = useState(nft_ref?.current?.getClientRects()[0].width);
    window.onresize = ()=>{
      try {
        let width = nft_ref.current.getClientRects()[0].width
        setHeight(width)
        console.log(width)
        setTimeout(() => {
          if(nft_ref.current){
            let width = nft_ref.current.getClientRects()[0].width
            setHeight(width)
          }
        }, 300);
      } catch (e) {
        console.log(e);
      }
    }
    
    useEffect(() => {
      
        let width = nft_ref?.current?.getClientRects()[0].width
        setHeight(width)
        
        setTimeout(() => {
          if(nft_ref.current){
            let width = nft_ref.current.getClientRects()[0].width
            setHeight(width)
          }
        }, 300);
      
    }, [setHeight]);


    return (
        <div className="collectionCard" onClick={onClick}>
            <div className="img_div" ref = {nft_ref} style = {{height : height}}>
                {/* <img src={`/assets/nfts/${id}.gif`} alt="" onLoad={(e)=>handleLoad(e)} onAbort = {()=>console.log('e.target')}/> */}
                <img src={`/assets/nfts/empty.png`} alt="" onLoad={(e)=>handleLoad(e)} onAbort = {()=>console.log('e.target')}/>
                {!isLoaded && <div className="loading-div"></div>}
                {/* <div className="id">
                <h4>#{id}</h4>
                </div>
                <div className={`rarity ${rarity}`}>
                    <h4>{rarity}</h4>
                </div> */}
            </div>
            
        </div>
    )
}
