import { useEffect, useState } from 'react';
import './rarity.scss'

const tmpList = [
    {
        type : 'assosiate',
        percent : 45,
        img: '/assets/rarity/assosiate.gif'
    },
    {
        type : 'soldier',
        percent : 25,
        img: '/assets/rarity/soldier.gif'
    },
    {
        type : 'Caporegime',
        percent : 15,
        img: '/assets/rarity/Caporegime.gif'
    },
    {
        type : 'Consigliere',
        percent : 10,
        img: '/assets/rarity/Consigliere.gif'
    },
    {
        type : 'Underboss',
        percent : 4,
        img: '/assets/rarity/Underboss.gif'
    },
    {
        type : 'boss',
        percent : 1,
        img: '/assets/rarity/boss.gif'
    }
]

type LoadingType = {
    setIsLoading?(flag: boolean): void;
};

export default function Rarity({ setIsLoading }: LoadingType) {

    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 6) {
            setTimeout(() => {
                setIsLoading(false)
            }, 1000);
        }
    }, [setIsLoading, imgCount]);

    return (
        <div className="rarity" id="rarity">
            <div className="rarityContent">
                <h1>trait rarity</h1>
                <div className="warpper" data-aos="fade-up">
                    {tmpList.map((d, k)=>(
                        <div className="item" key={k}>
                            <h3>{d.type}</h3>
                            <h3>{d.percent}%</h3>
                            <img src={d.img} alt="" onLoad = {onLoad}/>
                        </div>
                    ))}     
                    
                </div>
            </div>
        </div>
    )
}
