import Title from 'components/title/Title';
import { useEffect, useState } from 'react';
import './team.scss'

const tmpList = [
    {
        name : 'davidfilus',
        title : 'ARTIST',
        img: '/assets/nfts/6.gif',
        link : ''
    },
    {
        name : 'DEVko',
        title : 'developer',
        img: '/assets/nfts/9.gif',
        link : ''
    },
    {
        name : 'EARLY BIRDS',
        title : 'aDVISOR',
        img: '/assets/nfts/2.gif',
        link : 'https://twitter.com/ebgnft'
    },
    {
        name : 'Dara90',
        title : 'artist',
        img: '/assets/nfts/4.gif',
        link : ''
    },
    {
        name : 'MXJPB',
        title : 'developer',
        img: '/assets/nfts/1.gif',
        link : ''
    },
    {
        name : 'zEn',
        title : 'COMMUNITY MANAGER',
        img: '/assets/nfts/3.gif',
        link : ''
    },
    
]

type LoadingType = {
    setIsLoading?(flag: boolean): void;
};

export default function Team({ setIsLoading }: LoadingType) {

    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 7) {
            setTimeout(() => {
                setIsLoading(false)
            }, 1000);
        }
    }, [setIsLoading, imgCount]);

    return (
        <div className="team" id="team">
            <div className="teamContent">
                <h1>Meet the Team</h1>
                <div className="teamItem">
                    <img src="/assets/nfts/7.gif" alt=""  onLoad = {onLoad}/>
                    <Title 
                        label={
                        <div className="desc">
                            <h2>Hyphie</h2>
                            <hr />
                            <h3>Founder</h3>
                            <a href="https://twitter.com/egoHyphie" target={'_blank'} rel="noreferrer" ><i className="fab fa-twitter"></i></a>
                        </div>}
                    />
                </div>
                <div className="warpper" data-aos="fade-up">
                    {tmpList.map((d, k)=>(
                        <div className="item" key={k}>
                            <img src={d.img} alt="" onLoad = {onLoad}/>
                            <Title 
                                label={
                                <div className="desc">
                                    <h3>{d.name}</h3>
                                    <hr />
                                    <h3>{d.title}</h3>
                                    <a href={d.link} target={'_blank'} rel="noreferrer" ><i className="fab fa-twitter"></i></a>
                                </div>}
                            />
                        </div>
                    ))}     
                    
                </div>
            </div>
        </div>
    )
}
