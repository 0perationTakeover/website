import { useEffect, useState } from 'react';
import { HashLink } from 'react-router-hash-link'
import './home.scss'

type LoadingType = {
    setIsLoading?(flag: boolean): void;
};

export default function Home({ setIsLoading }: LoadingType) {

    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 2) {
            setTimeout(() => {
                setIsLoading(false)
            }, 1000);
        }
    }, [setIsLoading, imgCount]);

    return (
        <div className="home" id="home">
            <div className="homeContent">
                <div className="warpper" data-aos="fade-up">
                    <img src="/assets/mint.gif" alt="" className="hero" onLoad={onLoad} />
                    <div className="text">
                    <h2>Welcome to Elysian City, the most corrupt city on the blockchain.</h2>
                    <h2>Controlled by one of the biggest mob bosses in the world... His name? Cueball. </h2>
                    <h2>Cueball has been working to take full control of the city once and for all by creating 'The Agency', an army of 10,000 biologically created agents that are</h2>
                    <h2>made for one thing, to kill. </h2>
                    <h2>Will you become a loyal member of Cueball's plan for world domination?</h2>
                    <div className="btns">
                    <HashLink to="/mint" smooth className = "mintBtn">Mint</HashLink>
                    <HashLink to="#about" smooth>LEARN MORE</HashLink>
                    </div>
                    </div>
                </div>
            </div>
            <img src="/assets/back.gif" alt="" className="back" onLoad={onLoad}/>
        </div>
    )
}
