import { useEffect, useState } from 'react';
import './community.scss'

type LoadingType = {
    setIsLoading?(flag: boolean): void;
};

export default function Community({ setIsLoading }: LoadingType) {

    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 1) {
            setTimeout(() => {
                setIsLoading(false)
            }, 1000);
        }
    }, [setIsLoading, imgCount]);

    return (
        <div className="community" id="community">
            <div className="communityContent">
                <h1>JOIN OUR COMMUNITY</h1>
               
                <div className="warpper" data-aos="fade-up">
                    <p>Operation Takeover is nothing without <span>COMMUNITY.</span></p>

                    <p>As a holder of our collection, we insure to only make decisions that benefit <span>YOU.</span></p>

                    <p>Agents always have each others backs, which is why we will strive to create a central hub for all agents to call their <span>HOME.</span></p>

                    <p>Join the agency today and become a part of our mission to be <span>UNSTOPPABLE.</span></p>
                    <div className="btns">
                        <a href="/" target="_blank"rel="noreferrer">Purchase your agent</a> 
                        <a href="https://discord.gg/v885RBtttf" target="_blank"rel="noreferrer">Join our discord</a> 
                        <a href="https://twitter.com/Operation_TKO" target="_blank"rel="noreferrer">Follow us on twitter</a> 
                    </div>
                    <p>WE'RE NOT HERE TO <span>TAKE PART.</span></p>
                    <p>WE'RE HERE TO <span>TAKE OVER.</span></p>
                    <img src="/assets/stakingBack.gif" alt="" onLoad={onLoad}/>
                    <h3>Operation Takeover NFTS are not meant to be investment vehicles. No element of the Site, Site agreements, Site offerings and/or Operation Takeover NFTs qualifies as, or is intended to be, an offering of securities in any jurisdiction, nor does it constitute an offer or an invitation to purchase shares, securities or other financial products. NFTs, cryptocurrencies and blockchain technology are relatively new technologies and the regulatory landscape is unsettled. New regulations applicable to these technologies could negatively impact the value of your Operation Takeover NFTs. You are solely responsible for ensuring that the purchase of Operation Takeover NFTs complies with the laws and regulations of your jurisdiction.</h3>
                </div>
            </div>
        </div>
    )
}
