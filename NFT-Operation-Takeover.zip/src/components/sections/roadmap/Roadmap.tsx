import { useEffect, useState } from 'react';
import './roadmap.scss'
import Title from 'components/title/Title';

type LoadingType = {
    setIsLoading?(flag: boolean): void;
};

export default function Roadmap({ setIsLoading }: LoadingType) {

    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 3) {
            setTimeout(() => {
                setIsLoading(false)
            }, 1000);
        }
    }, [setIsLoading, imgCount]);


    return (
        <div className="roadmap" id="about">
            <div className="roadmapContent">
                <img src="/assets/Text for Banner - Upscaled size - 04.webp" alt="" className='titleImg' />
                
                <div className="top">
                    <div className="left">
                        <div className="txt">
                            <p>Operation Takeover is a storyline and brand Founded by web3 enthusiast, Hyphie.</p>
                            <p>Operation Takeover hopes to create one of the largest WEB3 communities in the space with the iteration of its first collection.</p>
                            <br/>
                            <p>The agency roam within Elysian City, a corrupt gang infested city, home to one of the most powerful mob bosses in the region and leader of The Agency, Cueball.</p>
                            <p>Cueball looks to secure full control of the city by working together with his new recruit, clinically insane, prof. Eugene Barkov to create 10,000 agents which are programmed to eliminate anyone in their way.</p>
                            <br/>
                            <p>$BloodMoney is the heart of the eco system. Agents will generate $BloodMoney daily which will have multiple uses throughout the roadmap.</p>
                            <p>Each agent will have their own loyalty meter, which will need $BLOODMONEY to level up. once this meter is filled you may prestige your agent, granting you extra rewards.</p>
                            <br/>
                            <p>Agents will have a wide variety of animated and non animated traits ranging from different weapons, outfits, wearables, and backgrounds. There will also be 10 legendary 1/1 NFTs that will be hidden within the collection and a number of special, rare agent NFTs that will be gifted to those who are loyal within the community and participate in community events. The winners will be voted on by the community and team.</p>
                        </div>
                    </div>
                    <div className="right">
                    <div className="imgs">
                        <img src="/assets/nfts/10.gif" alt="" onLoad = {onLoad}/>
                        <img src="/assets/nfts/8.gif" alt="" className='ml-100' onLoad = {onLoad}/>
                        <img src="/assets/nfts/5.gif" alt=""  onLoad = {onLoad}/>
                    </div>
                    </div>
                    
                    
                </div>
                <div className="warpper" data-aos="fade-up" id = 'roadmap'>
                    <div className="left">
                        <Title label={<><h1>Phase 1 - Cueballs plan</h1></>}/>
                        <br/>
                        <h4>PROJECT MINT</h4>
                        <p>Operation Takeover has begun. Cueballs plan has begun, With the help of Prof. Eugene Barkov, nothing will stop him as 10,000 lab created agents have been let loose throughout the city making sure no one ruins their plans.</p>

                        <h4>COMMUNITY WALLET</h4>
                        <p>A portion of the ETH raised through MINT & SECONDARY SALES will go into a community wallet. This ETH will be used for creating the best ideas that are entered into a community form. </p>
                        <p>A selection of ideas will be picked and put forward weekly/Monthly for the community to vote on.</p>

                        <h4>STAKING </h4>
                        <p>Each unlisted agent you own will generate 10 $BLOODMONEY per day, all you need to do is hold this NFT within your wallet. There will be a wide range of different things $BLOODMONEY will be used for which will expand overtime.</p>

                        <h4>DASHBOARD INTERGRATION</h4>
                        <p>Fully implementing your very own dashboard within the website. Here you can keep track of all your Operation Takeover NFTs, your $BLOODMONEY income and more exciting things that will come later down the roadmap.</p>
                        <h4>LEVEL YOUR AGENT</h4>

                        <p>Inject your agent with $BLOODMONEY to increase their loyalty level.</p>
                        <p>Levelling your agent will unlock new bonuses and rewards while also competing with other community members via our ranked leader board. Prestige your agent once your loyalty bar is full to unlock new badges displayed on your profile.</p>
                        <h4>VIP COLLECTION</h4>

                        <p>Our VIP collection will be in the works.</p>
                        <p>These can only be acquired through the BLACK MARKET or AIRDROP. </p>
                        <p>This will be a very small and sought after collection consisting of only the very best. </p>
                        <p>Holding a VIP pass will put you at the top of the food chain, granting you a boost with every key utility we have now and in the future.</p>
                        <p>You will also gain access to our VIP channel within the Operation Takeover discord, where you will receive priority access to information about upcoming news, drops and products we have in the works.</p>
                        <p>Holding a VIP pass will grant you FREE MINTS to ALL upcoming drops, priority to A+ WL allocations, IRL events and express support within the discord.</p>
                    </div>
                    <div className="right">
                        <Title label={<h1>Phase 2 - taking control</h1>}/>
                        <br/>
                        <h4>SUPPORTING PROJECTS & COLLABORATIONS</h4>
                        <p>Pixels support pixels! We will be looking to collaborate with NEW and ESTABLISHED projects/communities with a real love for the NFT space to create amazing crossover experiences for our holders.</p>

                        <h4>CAPTAIN REDEYES CHEST YOUR LUCK</h4>
                        <p>Open different rarity of chests for a chance to obtain a variety of cool prizes.</p>
                        <p>There will also be some exclusive prizes hidden for a few lucky agents to claim.</p>

                        <h4>THE BLACK MARKET</h4>
                        <p>Leader of the dead and seller of all things necessary, Captain Redeye joins forces with Cueball to
                        control sea & land, bringing you the opening of the BLACK MARKET. </p>
                        <p>Spend your $BLOODMONEY on EXCLUSIVE items which will expand overtime.</p>

                        <h4>APARTMENTS</h4>
                        <p>It's time to live in the big city. Claim your apartment using $BLOODMONEY.</p>
                        <p>Apartments will range from SMALL all the way to PENTHOUSE </p>
                        <p>with 10 secret legendary skyscrapers to be minted</p>


                        <h4>APARTMENT BUILDER</h4>
                        <p>Fully customise your apartment within your dashboard. A changing catalogue of apartment items will be available for purchase with your $BLOODMONEY which you can use to design your home. Ranging from limited edition holiday themed items along with some RARE EXCLUSIVE items which the most loyal community members will be able to purchase</p>

                        <h4>THE EXPEREMENT</h4>
                        <p>Prof. Barkov has made a breakthrough...</p>
                        <p>What could this be? We will need to collect some DNA samples for him to experiment further.</p>

                        <h4>CODE BLACK</h4>
                        <p>Barkov is missing and the lab is destroyed.. What the hell happened here? </p>
                        <p>Code BLACK is in full operation, ALL agents are assigned to high alert. Barkov must be found. </p>
                    </div>
                </div>
                <div className="bottom">
                    <button>More coming soon...</button>
                </div>
            </div>
        </div>
    )
}
