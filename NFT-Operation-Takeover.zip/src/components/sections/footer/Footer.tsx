import { useEffect, useState } from 'react';
import './footer.scss'
import { HashLink } from 'react-router-hash-link'
import { useHistory } from 'react-router-dom';
type LoadingType = {
    setIsLoading?(flag: boolean): void;
};

export default function Footer({ setIsLoading }: LoadingType) {

    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 1) {
            setTimeout(() => {
                setIsLoading(false)
            }, 1000);
        }
    }, [setIsLoading, imgCount]);

    const [tabID, setTabID] = useState('mycollection');
    const location = useHistory();
    useEffect(() => {
        const path = location.location.pathname.replace('/','')
        setTabID(path)
        console.log()
    }, [location]);

    return (
        <div className="footer" id="footer">
            <div className="footerContent">
                <div className="warpper">
                    
                    <div className="right">
                    <HashLink to="#home" smooth style = {{color : tabID === ('bloodmoney') ? '#f00' : '#f7df39', borderColor : tabID === ('bloodmoney') ? '#f00' : '#f7df39'}}>
                    <i className="fas fa-chevron-up"></i>
                    </HashLink>
                    {tabID === 'bloodmoney' ? 
                    <img src="assets/c966ca_d4f12059434f431f90161cdda20e87de_mv2.gif" alt="" className=''/>:
                    <img src="assets/footLogo.gif" alt="" className=''/>}
                    </div>
                </div>
                <div className="warpper">
                <div className="socialLinks">
                        <a href="/" target="_blank"rel="noreferrer">
                            <img src="/assets/opensea.png" alt="" onLoad = {onLoad}/>
                        </a> 
                        <a href="https://twitter.com/Operation_TKO" target="_blank"rel="noreferrer">
                        <img src="/assets/twitter.png" alt="" onLoad = {onLoad}/>
                        </a> 
                        <a href="https://discord.gg/v885RBtttf" target="_blank"rel="noreferrer">
                        <img src="/assets/discord.png" alt="" onLoad = {onLoad}/>
                        </a> 
                    </div>
                <p>© 2023 OPERATION TAKEOVER ALL RIGHTS RESERVED.</p>
                </div>
                
            </div>
        </div>
    )
}
