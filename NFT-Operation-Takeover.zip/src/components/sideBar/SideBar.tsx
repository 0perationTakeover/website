import "./sideBar.scss"
import {HashLink} from 'react-router-hash-link'
import { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { NFTStakingEngineDetail } from "utils/typs";
import { useWeb3React } from "@web3-react/core";
import { scGetStakingEngineInfo } from "utils/contracts";
import { currentNetwork } from "utils";

type LoadingType = {
    setIsLoading?(flag: boolean): void;
};
export default function SideBar({setIsLoading}:LoadingType) {
    const [menuOpen, setMenuOpen] = useState(false);
    const [tabID, setTabID] = useState('mycollection');

    const location = useHistory();

    useEffect(() => {
        const path = location.location.pathname.replace('/','')
        setTabID(path)
    }, [location]);

    const [imgCount, setImgCount] = useState(0);
    const onLoad = () => {
        setImgCount(imgCount + 1)
    }
    useEffect(() => {
        if (imgCount === 2) {
            setTimeout(() => {
                setIsLoading(false)
            }, 1000);
        }
    }, [setIsLoading, imgCount]);
    
    const { connector, library, chainId, account, active } = useWeb3React();
    const [stakingEngineDetail, setStakingEngineDetail] = useState<NFTStakingEngineDetail>(null);
    useEffect(() => {
        const isLoggedin = account && active && chainId === parseInt(currentNetwork);
        if (isLoggedin) {
            scGetStakingEngineInfo(account).then(
                (engineDetail: NFTStakingEngineDetail) => {
                    setStakingEngineDetail(engineDetail);
                }
            );
        }
    }, [connector, library, account, active, chainId, stakingEngineDetail?.currentNFTList]);
    return (
       <>
        <div className={"sidebar " + (menuOpen && "active")}>
            <div className="logo">
            <HashLink to="#"><img src="/assets/sideLogo.png" alt="" onLoad={onLoad}/></HashLink>
            </div>
            <ul>
                <li onClick = {()=> setMenuOpen(false)} className = {tabID === 'mycollection' ? "active": ''}>
                    <HashLink to="/mycollection"><i className="far fa-images icon"></i>My Collection</HashLink>
                </li>
                <li onClick = {()=> setMenuOpen(false)} className = {tabID === 'staking' ? "active": ''}>
                <HashLink to="/staking" smooth><i className="fas fa-coins icon"></i>Staking</HashLink>
                </li>
                <li onClick = {()=> setMenuOpen(false)} className = {"menuItem3 " + (menuOpen && "active")}>
                    <div className="socialLinks">
                        <a href="/" target="_blank"rel="noreferrer">
                            <img src="/assets/opensea.png" alt=""  onLoad={onLoad}/>
                        </a> 
                        <a href="https://twitter.com/Operation_TKO" target="_blank"rel="noreferrer">
                        <img src="/assets/twitter.png" alt=""  onLoad={onLoad}/>
                        </a> 
                        <a href="https://discord.gg/v885RBtttf" target="_blank"rel="noreferrer">
                        <img src="/assets/discord.png" alt=""  onLoad={onLoad}/>
                        </a> 
                    
                    </div>
                </li>
            </ul>
            <div className="balance">
                <h3>BALANCE</h3>
                <div className="state">
                    <h2>$BLOODMONEY</h2>
                    <p>{(stakingEngineDetail?.rewardsTokenBalance || 0).toFixed(2)}</p>
                </div>
                
            </div>
        </div>
        <div className={(menuOpen ? "hamburger active" : "hamburger")} onClick={() => setMenuOpen(!menuOpen)}>
            <span className="line1"></span>
            <span className="line2"></span>
            <span className="line3"></span>
        </div>
        </>
    )
}

