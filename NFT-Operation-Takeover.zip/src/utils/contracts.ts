import "@ethersproject/shims"
import { BigNumber, ethers } from "ethers";
import { currentNetwork, getContractObj } from ".";
import { NFTStakingEngineDetail, NFTMintEngineDetail } from "./typs";
import { RPC_URLS } from "./connectors";

import whitelistTree from "./merkleTree/whitelistTree.json";
import rarityTree from "./merkleTree/rarityTree.json";

export async function scGetMintEngineInfo(account) {
    const jsonProvider = new ethers.providers.JsonRpcProvider(RPC_URLS[currentNetwork]);
    const NFTContract = getContractObj('NFT_MINT_STAKING', currentNetwork, jsonProvider);
    try {
        const [
            maxSupply,
            totalSupply,
            whitelistPrice,
            publicPrice,
            saleStep,
            whitelistMintLimit,
            publicMintLimit,
            whitelistMintAmount,
            publicMintAmount,
        ] = await Promise.all([
            NFTContract.m_nMaxSupply(),
            NFTContract.totalSupply(),
            NFTContract.m_nWhitelistPrice(),
            NFTContract.m_nPublicPrice(),
            NFTContract.m_nSaleStep(),
            NFTContract.m_nWhitelistMintLimit(),
            NFTContract.m_nPublicMintLimit(),
            account ? NFTContract.m_mapWhitelistMintAmount(account) : BigNumber.from(0),
            account ? NFTContract.m_mapPublicMintAmount(account) : BigNumber.from(0),
        ]);

        const mintDetail: NFTMintEngineDetail = {
            maxSupply: maxSupply.toNumber(),
            totalSupply: totalSupply.toNumber(),
            whitelistPrice: parseFloat(ethers.utils.formatEther(whitelistPrice)),
            publicPrice: parseFloat(ethers.utils.formatEther(publicPrice)),
            saleStep: saleStep,
            whitelistMintLimit: whitelistMintLimit.toNumber(),
            publicMintLimit: publicMintLimit.toNumber(),
            whitelistMintAmount: whitelistMintAmount.toNumber(),
            publicMintAmount: publicMintAmount.toNumber(),
        }

        return mintDetail;
    } catch (e) {
        console.log(e);
        return null;
    }
}

export async function scWhitelistMint(chainId, provider, account, amount) {
    const NFTContract = getContractObj('NFT_MINT_STAKING', chainId, provider);
    try {
        var proof = whitelistTree["claims"][account]?.proof;
        if (proof === undefined) {
            return false;
        };

        const price: BigNumber = await NFTContract.m_nWhitelistPrice();
        const tx = await NFTContract.whitelistMint(amount, proof, {
            value: price.mul(amount)
        });
        await tx.wait(1);

        return true;
    } catch (e) {
        console.log(e);
        return false;
    }
}

export async function scPublicMint(chainId, provider, amount) {
    const NFTContract = getContractObj('NFT_MINT_STAKING', chainId, provider);
    try {
        const price: BigNumber = await NFTContract.m_nPublicPrice();
        const tx = await NFTContract.publicMint(amount, {
            value: price.mul(amount)
        });
        await tx.wait(1);

        return true;
    } catch (e) {
        console.log(e);
        return false;
    }
}


export async function scGetStakingEngineInfo(account) {
    const jsonProvider = new ethers.providers.JsonRpcProvider(RPC_URLS[currentNetwork]);
    const NFTContract = getContractObj('NFT_MINT_STAKING', currentNetwork, jsonProvider);
    const TokenContract = getContractObj('BlookMoney_Token', currentNetwork, jsonProvider);

    try {
        const [
            tokenDecimals,
            rewardsTokenBalance,
            pendingRewards,
            currentNFTList,
            stakedNFTList,
            userStakeInfo,
        ] = await Promise.all([
            TokenContract.decimals(),
            account ? TokenContract.balanceOf(account) : BigNumber.from(0),
            account ? NFTContract.pendingRewards(account) : BigNumber.from(0),
            account ? NFTContract.holdingNFTs(account) : [],
            account ? NFTContract.stakedNFTs(account) : [],
            account ? NFTContract.userStakeInfo(account) : null,
        ]);

        const stakingDetail: NFTStakingEngineDetail = {
            rewardsTokenBalance: parseFloat(ethers.utils.formatUnits(rewardsTokenBalance, tokenDecimals)),
            pendingRewards: parseFloat(ethers.utils.formatUnits(pendingRewards, tokenDecimals)),
            currentNFTList: currentNFTList,
            stakedNFTList: stakedNFTList,
            rewardsPerDay: userStakeInfo ? parseFloat(ethers.utils.formatUnits(userStakeInfo.rewardsPerDay, tokenDecimals)) : 0.00,
            paidRewards: userStakeInfo ? parseFloat(ethers.utils.formatUnits(userStakeInfo.paidRewards, tokenDecimals)) : 0.00,
            lastUpdatedTime: userStakeInfo ? userStakeInfo.lastUpdatedTime.toNumber() : 0,
        }

        return stakingDetail;
    } catch (e) {
        console.log(e);
        return null;
    }
}

export async function scStakeNFTs(chainId, provider, account, tokenIDList) {
    const NFTContract = getContractObj('NFT_MINT_STAKING', chainId, provider);
    try {
        var rarityList = [];
        var proofList = [];
        for (let i = 0; i < tokenIDList.length; i++) {
            const rarity = rarityTree["claims"][tokenIDList[i]]?.rarity;
            const proof = rarityTree["claims"][tokenIDList[i]]?.proof;
            if (rarity === undefined || proof === undefined) {
                return false;
            };
            rarityList.push(rarity);
            proofList.push(proof);
        }
        const isApprovedForAll: boolean = await NFTContract.isApprovedForAll(account, NFTContract.address);
        if (isApprovedForAll !== true) {
            const tx1 = await NFTContract.setApprovalForAll(NFTContract.address, true);
            await tx1.wait(1);
        }

        const tx2 = await NFTContract.stake(tokenIDList, rarityList, proofList);
        await tx2.wait(1);
        return true;

    } catch (e) {
        console.log(e);
        return false;
    }
}

export async function scUnStakeNFTs(chainId, provider, tokenIDList) {
    const NFTContract = getContractObj('NFT_MINT_STAKING', chainId, provider);
    try {
        var rarityList = [];
        var proofList = [];
        for (let i = 0; i < tokenIDList.length; i++) {
            const rarity = rarityTree["claims"][tokenIDList[i]]?.rarity;
            const proof = rarityTree["claims"][tokenIDList[i]]?.proof;
            if (rarity === undefined || proof === undefined) {
                return false;
            };
            rarityList.push(rarity);
            proofList.push(proof);
        }
        const tx2 = await NFTContract.unstake(tokenIDList, rarityList, proofList);
        await tx2.wait(1);
        return true;

    } catch (e) {
        console.log(e);
        return false;
    }
}

export async function scHarvest(chainId, provider) {
    const NFTContract = getContractObj('NFT_MINT_STAKING', chainId, provider);
    try {
        const tx = await NFTContract.harvest();
        await tx.wait(1);

        return true;
    } catch (e) {
        console.log(e);
        return false;
    }
}

