import { BigNumber } from "ethers";

export interface NFTMintEngineDetail {
    maxSupply: number;
    totalSupply: number;
    whitelistPrice: number;
    publicPrice: number;
    saleStep: number;
    whitelistMintLimit: number;
    publicMintLimit: number;
    whitelistMintAmount: number;
    publicMintAmount: number;
}

export interface NFTStakingEngineDetail {
    rewardsTokenBalance: number;
    pendingRewards: number;
    currentNFTList: [];
    stakedNFTList: [];
    rewardsPerDay: number;
    paidRewards: number;
    lastUpdatedTime: number;
}